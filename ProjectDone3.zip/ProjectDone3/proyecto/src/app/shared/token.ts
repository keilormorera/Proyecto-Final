export class Token {
    success: boolean;
    data: {
        token: string;
    };
}
