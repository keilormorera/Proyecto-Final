import { Injectable } from '@angular/core';
import { Contacto } from './contacto';
import {
  HttpClient,
  HttpErrorResponse,
  HttpResponse,
} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import { Token } from '../shared/token';

@Injectable()

export class ContactoService {
    private orderUrl = 'http://localhost:8000/contacto';

    constructor(private http: HttpClient) {}

    SendEmail(token: Token, order: Contacto): Observable<Contacto> {

        return this.http
          .post<Contacto>(`${this.orderUrl}`, order, {
            headers: { token: token.data.token },
          })
          .catch(this.handleError);
    }

    private handleError(err: HttpErrorResponse) {
        // tslint:disable-next-line:no-console
        console.log(err.message);
        return Observable.throw(err.message);
    }

}
