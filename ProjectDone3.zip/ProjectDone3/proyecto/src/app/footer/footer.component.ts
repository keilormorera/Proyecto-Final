import { Component, OnInit, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ContactoService } from './contacto.service';
import { AuthService } from '../shared/auth.service';
import { Token } from '../shared/token';
import { Contacto } from './contacto';
import {NgForm} from '@angular/forms';
import { RouterModule, Routes, Router } from '@angular/router';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  @Input() contacto: Contacto;
  token: Token;
  errorMessage: string;

  correo: string;

  constructor(private router: Router, private authService: AuthService, private contactoService: ContactoService) { }

  ngOnInit() {
  }

  onSubmit(form: NgForm) {
    this.authService.login().subscribe(
      token => {
        this.token = token;
        if (this.contacto === undefined) {
          this.contacto = new Contacto();
        }
        this.contacto.nombre = 'Ánonimo';
        this.contacto.correo = this.correo;
        this.contacto.mensaje = 'Información';

        this.contactoService.SendEmail(this.token, this.contacto).subscribe(
          arbitro => {
            form.reset();
            this.router.navigate(['']);
          },
          error => (this.errorMessage = <any>error),
        );
      },
      error => (this.errorMessage = <any>error),
    );
  }

}
