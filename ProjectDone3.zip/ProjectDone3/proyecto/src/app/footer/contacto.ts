export class Contacto {
    nombre: string;
    correo: string;
    mensaje: string;
}
