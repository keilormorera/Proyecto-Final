const Sequelize = require('sequelize');
const sequelize = require('../db');

const User = sequelize.define('user', {
    login: Sequelize.STRING,
    password: Sequelize.STRING,
});

const Contacto = sequelize.define('contacto', {
    nombre: Sequelize.STRING,
    correo: Sequelize.STRING,
    mensaje: Sequelize.STRING,
});


module.exports = {
    User,
    Contacto,
}