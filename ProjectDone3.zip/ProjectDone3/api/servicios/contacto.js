contactos = require('../modelos').Contacto;

const addContacto = contacto => contactos.create(contacto);


module.exports = {
    addContacto,
};