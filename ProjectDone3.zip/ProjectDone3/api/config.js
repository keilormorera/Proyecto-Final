module.exports = {
        port: 8000,
        dbConnectionString: "postgres://postgres:fss123@localhost:5432/api_email",
        operatorsAliases: false,
        saltRounds: 2,
        jwtSecret: 'yocreoenlautn',
        tokenExpireTime: '2w'
    }
    //No salvar este archivo es "peligroso"