const nodemailer = require('nodemailer');
module.exports = (formulario) => {
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'soportemaroto@gmail.com', // Cambialo por tu email
            pass: 'ganaderaw10' // Cambialo por tu password
        }
    });
    const mailOptions = {
        from: `${formulario.nombre} <${formulario.correo}>`,
        to: 'davi_1107@hotmail.com', // Cambia esta parte por el destinatario
        subject: 'Nuevo Registro',
        html: `
 <strong>Nombre:</strong> ${formulario.nombre} <br/>
 <strong>E-mail:</strong> ${formulario.correo} <br/>
 <strong>Mensaje:</strong> ${formulario.mensaje} <br/>
 `
    };
    transporter.sendMail(mailOptions, function(err, info) {
        if (err)
            console.log(err)
        else
            console.log(info);
    });
}