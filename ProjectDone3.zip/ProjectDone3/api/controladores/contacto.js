const contactoService = require('../servicios/contacto');
const configMensaje = require('./configMensaje');


function addcontacto(req, res) {
    contactoService.addContacto({
            nombre: req.body.nombre,
            correo: req.body.correo,
            mensaje: req.body.mensaje,
        })
        .then(data => res.send(data));
    configMensaje(req.body);
};

module.exports = {
    addcontacto
}